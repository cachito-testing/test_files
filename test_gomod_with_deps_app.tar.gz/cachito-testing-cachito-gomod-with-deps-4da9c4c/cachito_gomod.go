package cachitoGomodTest

import "rsc.io/quote"

func CachitoGomodTest() string {
    return quote.Hello()
}

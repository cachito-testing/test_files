package foo

// No newline at the end of this line
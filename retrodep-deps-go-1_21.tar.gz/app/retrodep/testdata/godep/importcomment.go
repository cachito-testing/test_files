package foo // import "godep/foo"

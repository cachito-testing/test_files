This package collects pithy sayings.

It's part of a demonstration of
[package versioning in Go](https://research.swtch.com/vgo1).
